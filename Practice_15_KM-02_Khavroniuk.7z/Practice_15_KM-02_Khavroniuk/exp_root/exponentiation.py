def exp2(n):
    result = n*n
  
    print(result)
def exp3(n):
    result = n*n*n
   
    print(result)